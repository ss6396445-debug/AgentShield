# Security Policy

AgentShield is defensive software. It should be used to identify and reduce security risks in systems you own or are authorized to assess.

## Reporting

Do not include live credentials, personal data, or sensitive production configuration in public issues. Provide a minimal reproducible example whenever possible.
