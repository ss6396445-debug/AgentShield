import json
from agentshield.repo import scan_repository

def test_repository_scan(tmp_path):
    (tmp_path/"mcp.json").write_text(json.dumps({"command": "shell_exec"}))
    (tmp_path/"notes.txt").write_text("not a config")
    results = scan_repository(tmp_path)
    assert len(results) == 1
    assert results[0]["source"].endswith("mcp.json")
    assert any(x["rule"] == "command-execution" for x in results[0]["findings"])
