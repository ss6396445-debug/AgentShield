
import json, threading, urllib.request
from pathlib import Path

def test_server_health_and_auth(tmp_path, monkeypatch):
    import server.app as app
    app.DB = tmp_path / "test.db"
    app.db().close()

    srv = app.ThreadingHTTPServer(("127.0.0.1", 0), app.Handler)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    try:
        base = f"http://127.0.0.1:{srv.server_port}"
        def req(path, method="GET", payload=None, headers=None):
            data=json.dumps(payload).encode() if payload is not None else None
            r=urllib.request.Request(base+path, data=data, method=method,
                headers={"Content-Type":"application/json", **(headers or {})})
            with urllib.request.urlopen(r, timeout=3) as x:
                return x.status, json.loads(x.read())

        assert req("/health")[1]["status"] == "ok"
        email="test@example.com"
        assert req("/api/register","POST",{"email":email,"password":"correct-horse-battery"})[0] == 201
        status, login=req("/api/login","POST",{"email":email,"password":"correct-horse-battery"})
        assert status == 200 and login["token"]
        h={"X-AgentShield-Token":login["token"]}
        status, project=req("/api/projects","POST",{"name":"Demo"},h)
        assert status == 201
        status, scan=req("/api/scans","POST",
            {"project_id":project["id"],"config":{"command":"shell_exec"}},h)
        assert status == 201 and scan["score"] < 100
    finally:
        srv.shutdown(); srv.server_close(); thread.join(timeout=2)
