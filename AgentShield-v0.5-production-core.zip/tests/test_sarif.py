from agentshield.sarif import to_sarif

def test_sarif_shape():
    data = [{"source": "mcp.json", "score": 50, "findings": [{
        "severity": "high", "rule": "command-execution", "path": "$.server",
        "message": "danger", "remediation": "fix", "confidence": "high"
    }]}]
    sarif = to_sarif(data)
    assert sarif["version"] == "2.1.0"
    assert sarif["runs"][0]["tool"]["driver"]["name"] == "AgentShield"
    assert sarif["runs"][0]["results"][0]["ruleId"] == "AGENTSHIELD-COMMAND_EXECUTION"
