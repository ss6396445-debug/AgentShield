import json
from agentshield.scanner import scan_config, calculate_score

def test_dangerous_config():
    data = {
        "server": {
            "command": "shell_exec",
            "url": "http://127.0.0.1:8080",
            "token_passthrough": True,
            "scope": "admin:*"
        }
    }
    findings = scan_config(data)
    rules = {f["rule"] for f in findings}
    assert "command-execution" in rules
    assert "ssrf-private-target" in rules
    assert "token-passthrough" in rules
    assert "broad-scope" in rules
    assert calculate_score(findings) <= 40

def test_secret():
    data = {"api_key": "ghp_" + "A"*24}
    rules = {f["rule"] for f in scan_config(data)}
    assert "secret-exposure" in rules

def test_safe_config():
    data = {"server": {"transport": "stdio", "sandbox": True, "permissions": ["read:docs"]}}
    findings = scan_config(data)
    assert findings[0]["rule"] == "no-known-risk"

def test_policy_inputs_are_stable():
    data = {"authorization": {"resource": "https://api.example.com", "scope": "read:docs"}}
    findings = scan_config(data)
    assert all("severity" in f and "rule" in f and "remediation" in f for f in findings)
