from agentshield.policy import evaluate

def test_policy_fails_high():
    results = [{"source": "mcp.json", "score": 60, "findings": [{
        "severity": "high", "rule": "command-execution", "path": "$"
    }]}]
    violations = evaluate(results, {"fail_on": ["critical", "high"], "minimum_score": 80, "ignored_rules": []})
    assert len(violations) == 2
