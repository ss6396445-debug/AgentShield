
import tempfile, json
from pathlib import Path
from server.db import DB
from reviewers.review import review_findings, findings_hash, diff_findings

def test_db_tenant_isolation():
    with tempfile.TemporaryDirectory() as d:
        db=DB(Path(d)/"x.db")
        db.add_user("u1","a@x","h"); db.add_user("u2","b@x","h")
        db.add_project("p1","u1","A"); db.add_project("p2","u2","B")
        assert db.project("p1","u1") is not None
        assert db.project("p1","u2") is None

def test_audit_and_baseline():
    with tempfile.TemporaryDirectory() as d:
        db=DB(Path(d)/"x.db")
        db.add_user("u","a@x","h"); db.add_project("p","u","P")
        db.add_scan("s","p","queued","test")
        fs=[{"rule":"AS001","severity":"high","message":"unsafe"}]
        db.finish_scan("s",70,fs)
        db.set_baseline("p","s",findings_hash(fs))
        assert db.baseline("p")["scan_id"]=="s"
        assert db.scans("p")[0]["score"]==70

def test_review_gate_blocks_secret_disclosure():
    ok=review_findings([{"rule":"AS001","severity":"high","message":"safe"}])
    bad=review_findings([{"rule":"AS002","severity":"high","message":"token=SECRET"}])
    assert ok["passed"] and not bad["passed"]

def test_diff():
    a=[{"rule":"A","severity":"low"}]
    b=[{"rule":"A","severity":"low"},{"rule":"B","severity":"high"}]
    d=diff_findings(a,b)
    assert len(d["new"])==1 and d["resolved"]==[] and d["unchanged"]==1
