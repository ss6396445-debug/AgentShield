# AgentShield SaaS Architecture — v0.4

## Implemented reference layer
- Registration/login with salted scrypt password hashes
- Random bearer sessions
- Tenant ownership checks on projects/scans
- Project dashboard
- Scan history
- API scan endpoint
- Security headers and payload-size limit
- Reuse of the defensive scanner engine

## Production hardening required before public launch
1. PostgreSQL + migrations
2. Redis/queue workers for scans
3. Object storage for reports
4. GitHub OAuth/App installation and webhook verification
5. Stripe billing and entitlements
6. CSRF protection for browser sessions if cookie auth is introduced
7. Secret management/KMS
8. Structured audit logs
9. Rate limiting and abuse prevention
10. Multi-tenant isolation tests
11. Dependency and container scanning
12. Privacy policy, DPA, retention controls
13. Observability, backups, disaster recovery
14. Independent penetration test before handling customer repositories

## Commercial model
Free CLI -> free GitHub CI -> hosted monitoring -> Team -> Business/Enterprise.
Do not charge for the basic scanner until the hosted product proves retention and demand.
