"""AgentShield: defensive AI-agent and MCP security scanning."""
__version__ = "0.3.0"
