from pathlib import Path
from .scanner import load_json, scan_data

CONFIG_NAMES = {
    "mcp.json", "mcp-config.json", "mcp_config.json",
    "claude_desktop_config.json", "agent-config.json",
    "agents.json", "agent.json"
}

def is_candidate(path: Path):
    if path.name.lower() in CONFIG_NAMES:
        return True
    n = path.name.lower()
    return any(k in n for k in ("mcp", "agent")) and path.suffix.lower() in {".json", ".jsonc"}

def scan_repository(root):
    root = Path(root)
    results = []
    for p in root.rglob("*"):
        if not p.is_file() or ".git" in p.parts:
            continue
        if not is_candidate(p):
            continue
        try:
            data = load_json(p)
        except Exception as exc:
            results.append({"source": str(p), "parse_error": str(exc), "score": 0, "findings": [{
                "severity": "high", "rule": "invalid-config", "path": "$",
                "message": f"Could not parse candidate configuration: {exc}",
                "remediation": "Fix JSON syntax or use a supported configuration format.",
                "confidence": "high"
            }]})
            continue
        results.append(scan_data(data, str(p)))
    return results
