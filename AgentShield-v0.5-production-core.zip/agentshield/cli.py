import argparse, json, sys
from pathlib import Path
from .scanner import scan_file
from .repo import scan_repository
from .sarif import write_sarif
from .policy import load_policy, evaluate

def _print_results(results):
    for result in results:
        print(f"\n{result.get('source')}: AgentShield Security Score {result.get('score')}/100")
        print("=" * 60)
        if result.get("parse_error"):
            print("[HIGH] invalid-config")
            print("  " + result["parse_error"])
            continue
        for f in result["findings"]:
            print(f"[{f['severity'].upper()}] {f['rule']} @ {f['path']}")
            print(f"  {f['message']}")
            print(f"  Fix: {f['remediation']}")

def main():
    p = argparse.ArgumentParser(prog="agentshield")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("scan")
    s.add_argument("target")
    s.add_argument("--json", action="store_true")
    s.add_argument("--sarif")
    s.add_argument("--policy")
    s.add_argument("--fail-on-policy", action="store_true")

    r = sub.add_parser("report")
    r.add_argument("file")
    r.add_argument("--output", required=True)

    args = p.parse_args()

    if args.command == "scan":
        target = Path(args.target)
        results = [scan_file(target)] if target.is_file() else scan_repository(target)
        if args.json:
            print(json.dumps(results[0] if target.is_file() else results, indent=2))
        else:
            _print_results(results)
        if args.sarif:
            write_sarif(results, args.sarif)
            print(f"\nSARIF written to {args.sarif}")
        if args.fail_on_policy:
            violations = evaluate(results, load_policy(args.policy))
            if violations:
                print(f"\nPolicy FAILED: {len(violations)} violation(s).")
                sys.exit(1)
            print("\nPolicy PASSED.")
    elif args.command == "report":
        result = scan_file(args.file)
        html = (Path(__file__).parent.parent / "web" / "dashboard.html").read_text(encoding="utf-8")
        payload = json.dumps(result).replace("</", "<\\/")
        Path(args.output).write_text(html.replace("__REPORT_DATA__", payload), encoding="utf-8")
        print(f"Report written to {args.output}")
