import json, re, ipaddress
from pathlib import Path
from urllib.parse import urlparse

PRIVATE_RANGES = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
]

SECRET_PATTERNS = [
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    re.compile(r"\bghp_[A-Za-z0-9]{20,}\b"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"(password|passwd|api[_-]?key|secret|token)\s*[:=]\s*['\"][^'\"]{8,}", re.I),
]

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
PENALTIES = {"critical": 30, "high": 15, "medium": 7, "low": 3, "info": 0}

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def _walk(obj, path="$"):
    yield path, obj
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _walk(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _walk(v, f"{path}[{i}]")

def _is_private_host(host):
    if not host:
        return False
    try:
        ip = ipaddress.ip_address(host)
        return any(ip in net for net in PRIVATE_RANGES)
    except ValueError:
        return host.lower() in {"localhost", "metadata.google.internal", "metadata.google.internal."}

def _finding(severity, rule, path, message, remediation, confidence="high"):
    return {
        "severity": severity,
        "rule": rule,
        "path": path,
        "message": message,
        "remediation": remediation,
        "confidence": confidence,
    }

def scan_config(data):
    findings, seen = [], set()
    def add(*args, **kwargs):
        f = _finding(*args, **kwargs)
        key = (f["severity"], f["rule"], f["path"], f["message"])
        if key not in seen:
            seen.add(key)
            findings.append(f)

    all_text = json.dumps(data, ensure_ascii=False).lower()

    for path, value in _walk(data):
        # Inspect primitive values and dictionary keys, but do not stringify
        # entire parent objects; doing so would duplicate child findings.
        candidates = []
        if isinstance(value, dict):
            candidates.extend((f"{path}.{k}", str(k)) for k in value.keys())
        elif isinstance(value, (str, int, float, bool)):
            candidates.append((path, str(value)))

        for signal_path, text in candidates:
            low = text.lower()

            for pattern in SECRET_PATTERNS:
                if pattern.search(text):
                    add("critical", "secret-exposure", signal_path,
                        "Possible plaintext credential or secret detected.",
                        "Rotate the exposed credential, remove it from configuration, and inject secrets at runtime through a secret manager.",
                        "high")
                    break

            if any(x in low for x in ["shell_exec", "shell.execute", "subprocess", "exec_command", "run_command", "os.system"]):
                add("high", "command-execution", signal_path,
                    "Tool/configuration appears to permit arbitrary command execution.",
                    "Require explicit approval, isolate execution, and apply command/path allowlists.",
                    "high")

            if any(x in low for x in ["write_file", "delete_file", "filesystem_write", "filesystem.delete", "fs_write", "rm -rf"]):
                add("high", "filesystem-write", signal_path,
                    "Agent capability can modify or delete files.",
                    "Restrict writable paths and require approval for destructive operations.",
                    "high")

            if any(x in low for x in ["http_request", "network_access", "fetch", "browser", "upload"]):
                add("medium", "network-access", signal_path,
                    "Agent capability can access external/network resources.",
                    "Use domain allowlists, egress controls, request logging, and SSRF protections.",
                    "medium")

            if "http://" in low and "localhost" not in low and "127.0.0.1" not in low:
                add("medium", "insecure-http", signal_path,
                    "HTTP URL detected where HTTPS may be expected.",
                    "Prefer HTTPS for authorization and production service endpoints.",
                    "high")

            if any(scope in low for scope in ["files:*", "db:*", "admin:*", "all:*", "read_write_all", "repo:*"]):
                add("high", "broad-scope", signal_path,
                    "Very broad authorization scope detected.",
                    "Replace wildcard/admin scopes with narrowly scoped permissions for the minimum operation required.",
                    "high")

            if any(x in low for x in ["token_passthrough", "forward_access_token", "passthrough_token", "forward_token"]):
                add("critical", "token-passthrough", signal_path,
                    "Configuration indicates access-token passthrough to another service.",
                    "Do not pass client tokens downstream; obtain a separately issued token bound to the intended resource.",
                    "high")

            if isinstance(value, str):
                for match in re.findall(r"https?://[^\s\"']+", value):
                    try:
                        parsed = urlparse(match)
                        if _is_private_host(parsed.hostname):
                            add("high", "ssrf-private-target", signal_path,
                                f"URL targets a private/reserved host: {parsed.hostname}",
                                "Block private/reserved ranges and cloud metadata endpoints unless explicitly required and controlled.",
                                "high")
                    except Exception:
                        pass

    # Global policy checks are emitted once, not once per nested object.
    if "stdio" in all_text and any(x in all_text for x in ["spawn", "command", "server"]):
        if not any(x in all_text for x in ["sandbox", "container", "isolation", "allowlist"]):
            add("high", "local-server-isolation", "$",
                "Local stdio server appears to execute without an obvious isolation control.",
                "Use sandboxing/containerization, restrict filesystem and network access, and log process execution.",
                "medium")

    if "oauth" in all_text or "authorization" in all_text:
        if "audience" not in all_text and "resource" not in all_text:
            add("high", "missing-token-audience-binding", "$",
                "Authorization-related configuration lacks an obvious audience/resource binding.",
                "Bind tokens to the intended resource and validate issuer, audience, scope and expiry.",
                "medium")

    if not findings:
        add("info", "no-known-risk", "$",
            "No known high-confidence risky patterns were found by the current ruleset.",
            "Continue with runtime testing, dependency review, and policy validation.",
            "medium")

    findings.sort(key=lambda x: (SEVERITY_ORDER[x["severity"]], x["rule"], x["path"]))
    return findings

def calculate_score(findings):
    return max(0, 100 - sum(PENALTIES[f["severity"]] for f in findings))

def scan_data(data, source="<memory>"):
    findings = scan_config(data)
    return {"score": calculate_score(findings), "findings": findings, "source": source}

def scan_file(path):
    return scan_data(load_json(path), str(path))
