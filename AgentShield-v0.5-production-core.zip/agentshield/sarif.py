import json

LEVEL = {"critical": "error", "high": "error", "medium": "warning", "low": "note", "info": "note"}

def to_sarif(results, tool_version="0.3.0"):
    rules = {}
    runs_results = []
    for result in results:
        source = result.get("source", "<memory>")
        for f in result.get("findings", []):
            rid = "AGENTSHIELD-" + f["rule"].upper().replace("-", "_")
            rules.setdefault(rid, {
                "id": rid,
                "shortDescription": {"text": f["rule"]},
                "fullDescription": {"text": f["message"]},
                "help": {"text": f["remediation"]},
                "properties": {"severity": f["severity"], "confidence": f.get("confidence", "high")}
            })
            runs_results.append({
                "ruleId": rid,
                "level": LEVEL[f["severity"]],
                "message": {"text": f["message"] + " Fix: " + f["remediation"]},
                "locations": [{
                    "physicalLocation": {
                        "artifactLocation": {"uri": source},
                        "region": {"startLine": 1}
                    }
                }],
                "partialFingerprints": {
                    "primaryLocationLineHash": f'{source}:{f["path"]}:{f["rule"]}'
                }
            })
    return {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {"name": "AgentShield", "version": tool_version, "rules": list(rules.values())}},
            "results": runs_results
        }]
    }

def write_sarif(results, output):
    with open(output, "w", encoding="utf-8") as fh:
        json.dump(to_sarif(results), fh, indent=2)
