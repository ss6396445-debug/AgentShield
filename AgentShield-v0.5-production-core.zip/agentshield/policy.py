import json
from pathlib import Path

DEFAULT_POLICY = {
    "fail_on": ["critical", "high"],
    "minimum_score": 80,
    "ignored_rules": []
}

def load_policy(path=None):
    if not path:
        return DEFAULT_POLICY.copy()
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    policy = DEFAULT_POLICY.copy()
    policy.update(data)
    return policy

def evaluate(results, policy):
    violations = []
    for result in results:
        if result.get("score", 0) < policy["minimum_score"]:
            violations.append({
                "type": "score",
                "source": result.get("source"),
                "score": result.get("score"),
                "minimum": policy["minimum_score"]
            })
        for f in result.get("findings", []):
            if f["rule"] in policy.get("ignored_rules", []):
                continue
            if f["severity"] in policy["fail_on"]:
                violations.append({
                    "type": "finding",
                    "source": result.get("source"),
                    "rule": f["rule"],
                    "severity": f["severity"],
                    "path": f["path"]
                })
    return violations
