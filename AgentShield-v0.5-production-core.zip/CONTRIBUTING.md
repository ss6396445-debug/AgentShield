# Contributing

All changes should include tests when behavior changes.

Before opening a pull request:

```bash
python -m pytest -q
agentshield scan examples/sample_mcp.json --json
```

Security-sensitive rule changes should include a positive and negative test to reduce false positives.
