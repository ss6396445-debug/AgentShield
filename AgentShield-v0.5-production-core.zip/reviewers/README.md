# Automated Review Gates

These are deterministic quality gates, not human reviewers. They check finding schema,
severity values, stable rule presence, and accidental secret disclosure in reports.

Production deployments should add external security review / penetration testing before
handling customer repositories at scale.
