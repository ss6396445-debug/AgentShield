import json, hashlib
from pathlib import Path

def review_findings(findings):
    """Independent deterministic review gate: schema, severity, stable IDs, secret-leak prevention."""
    errors=[]
    allowed={"critical","high","medium","low","info"}
    for i,f in enumerate(findings):
        if not isinstance(f,dict): errors.append(f"finding[{i}] not object"); continue
        if f.get("severity") not in allowed: errors.append(f"finding[{i}] invalid severity")
        if not f.get("rule"): errors.append(f"finding[{i}] missing rule")
        msg=str(f.get("message",""))
        if any(k in msg.lower() for k in ("password=","token=","secret=","api_key=")):
            errors.append(f"finding[{i}] possible secret disclosure")
    return {"passed":not errors,"errors":errors,"count":len(findings)}

def findings_hash(findings):
    canonical=json.dumps(findings,sort_keys=True,separators=(",",":")).encode()
    return hashlib.sha256(canonical).hexdigest()

def diff_findings(previous,current):
    old={json.dumps(x,sort_keys=True) for x in previous}
    new={json.dumps(x,sort_keys=True) for x in current}
    return {
        "new":[json.loads(x) for x in sorted(new-old)],
        "resolved":[json.loads(x) for x in sorted(old-new)],
        "unchanged":len(old & new)
    }
