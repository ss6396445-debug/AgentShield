# AgentShield v0.3

**Defensive AI-agent & MCP security scanner for developers and CI/CD.**

AgentShield focuses on a narrow, useful wedge: finding risky MCP/agent configuration before deployment and enforcing policy in GitHub pull requests.

## What it detects

- Plaintext credentials and common API-token patterns
- Command/shell execution capability
- Filesystem write/delete capability
- Network/HTTP access
- Insecure HTTP endpoints
- Broad/wildcard authorization scopes
- OAuth/MCP token passthrough
- Missing resource/audience binding indicators
- SSRF indicators for private/reserved hosts
- Local stdio servers without obvious isolation controls

## v0.3 capabilities

- Single-file scanning
- Repository scanning
- JSON output
- SARIF 2.1.0 output for GitHub Code Scanning
- Policy-as-code with minimum score and fail-on-severity
- GitHub Actions workflow
- Automated test suite

## Local use

```bash
python -m pip install -e .
agentshield scan examples/sample_mcp.json
agentshield scan . --sarif agentshield-results.sarif --policy examples/policy.json --fail-on-policy
```

## Product strategy

The open-source scanner is the acquisition wedge. A future hosted product can add:
1. Repository onboarding and scan history
2. Baselines and diff-aware findings
3. Scheduled monitoring and alerts
4. Organization policies and audit logs
5. Team/enterprise controls and integrations

AgentShield is defensive: it does not exploit targets or execute discovered commands.
