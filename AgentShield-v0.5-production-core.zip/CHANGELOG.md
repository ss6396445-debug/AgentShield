# Changelog

## 0.5.0
- Added persistent data layer and tenant isolation primitives.
- Added scan queue abstraction.
- Added audit logs and scan baselines.
- Added deterministic review gates and finding diffs.
- Added Docker/Compose reference deployment.
- Added production readiness checklist.
