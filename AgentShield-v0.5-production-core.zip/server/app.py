
import json, sqlite3, secrets, hashlib, html
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agentshield.scanner import scan_file

DB = ROOT / "agentshield.db"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS projects(
      id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL,
      name TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS scans(
      id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL,
      source TEXT NOT NULL, score INTEGER NOT NULL,
      findings_json TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS sessions(
      token TEXT PRIMARY KEY, user_id INTEGER NOT NULL,
      expires_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    """)
    return c

def pw_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1).hex()
    return salt + "$" + digest

def pw_check(password, stored):
    salt, digest = stored.split("$", 1)
    return secrets.compare_digest(pw_hash(password, salt).split("$",1)[1], digest)

def page(title, body):
    return f"""<!doctype html><html><head><meta charset=utf-8>
    <meta name=viewport content="width=device-width,initial-scale=1">
    <title>{html.escape(title)}</title>
    <style>
    body{{font-family:system-ui;max-width:1050px;margin:40px auto;padding:0 18px}}
    nav{{display:flex;justify-content:space-between;align-items:center}}
    .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}}
    .card{{border:1px solid #ddd;border-radius:14px;padding:18px}}
    input,button,textarea{{width:100%;padding:10px;margin:5px 0;box-sizing:border-box}}
    button{{cursor:pointer}}
    .score{{font-size:40px;font-weight:700}}
    .critical{{border-left:6px solid #900}}.high{{border-left:6px solid #d60}}
    .medium{{border-left:6px solid #ca0}}.low,.info{{border-left:6px solid #777}}
    a{{text-decoration:none}}
    </style></head><body>{body}</body></html>"""

class Handler(BaseHTTPRequestHandler):
    def send(self, status=200, body="", content_type="text/html"):
        data = body.encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type+"; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'unsafe-inline'")
        self.end_headers(); self.wfile.write(data)

    def token_user(self):
        token = self.headers.get("X-AgentShield-Token","")
        if not token: return None
        c=db(); row=c.execute("SELECT user_id FROM sessions WHERE token=?", (token,)).fetchone()
        if not row: return None
        return row["user_id"]

    def read_json(self):
        n=int(self.headers.get("Content-Length","0"))
        if n > 2_000_000: raise ValueError("payload too large")
        return json.loads(self.rfile.read(n) or "{}")

    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/health":
            return self.send(200, json.dumps({"status":"ok","service":"agentshield"}), "application/json")
        uid=self.token_user()
        if path=="/" and not uid:
            return self.send(200,page("AgentShield", """<h1>AgentShield</h1>
            <p>AI-agent & MCP security posture management.</p>
            <div class=grid><div class=card><h2>Scan</h2><p>Detect risky agent/MCP configuration before deployment.</p></div>
            <div class=card><h2>Policy</h2><p>Enforce security gates in CI.</p></div>
            <div class=card><h2>Monitor</h2><p>Track project security over time.</p></div></div>
            <p><b>API:</b> POST /api/register, /api/login, /api/projects, /api/scans</p>"""))
        if path=="/dashboard" and uid:
            c=db(); projects=c.execute("SELECT * FROM projects WHERE user_id=? ORDER BY id DESC",(uid,)).fetchall()
            cards=[]
            for p in projects:
                scans=c.execute("SELECT * FROM scans WHERE project_id=? ORDER BY id DESC LIMIT 5",(p["id"],)).fetchall()
                latest=scans[0] if scans else None
                cards.append(f"""<div class=card><h2>{html.escape(p['name'])}</h2>
                <div class=score>{latest['score'] if latest else '—'}/100</div>
                <p>{len(scans)} recent scan(s)</p>
                <a href="/project/{p['id']}">Open project →</a></div>""")
            return self.send(200,page("Dashboard","<nav><h1>AgentShield</h1><span>Dashboard</span></nav><div class=grid>"+''.join(cards)+"</div>"))
        if path.startswith("/project/") and uid:
            pid=path.split("/")[-1]; c=db()
            p=c.execute("SELECT * FROM projects WHERE id=? AND user_id=?",(pid,uid)).fetchone()
            if not p: return self.send(404,"Not found")
            scans=c.execute("SELECT * FROM scans WHERE project_id=? ORDER BY id DESC LIMIT 20",(pid,)).fetchall()
            body=f"<h1>{html.escape(p['name'])}</h1><p><a href=/dashboard>← Dashboard</a></p>"
            for s in scans:
                body+=f"<div class=card><b>Score {s['score']}/100</b><small> — {s['created_at']}</small><pre>{html.escape(s['findings_json'][:3000])}</pre></div>"
            return self.send(200,page(p["name"],body))
        self.send(404,"Not found")

    def do_POST(self):
        path=urlparse(self.path).path
        try: data=self.read_json()
        except Exception as e: return self.send(400,json.dumps({"error":str(e)}),"application/json")
        c=db()
        if path=="/api/register":
            email=str(data.get("email","")).strip().lower()
            password=str(data.get("password",""))
            if "@" not in email or len(password)<10: return self.send(400,json.dumps({"error":"valid email and password >= 10 chars required"}),"application/json")
            try:
                cur=c.execute("INSERT INTO users(email,password_hash) VALUES(?,?)",(email,pw_hash(password))); c.commit()
            except sqlite3.IntegrityError: return self.send(409,json.dumps({"error":"account already exists"}),"application/json")
            return self.send(201,json.dumps({"user_id":cur.lastrowid}),"application/json")
        if path=="/api/login":
            row=c.execute("SELECT * FROM users WHERE email=?",(str(data.get("email","")).lower(),)).fetchone()
            if not row or not pw_check(str(data.get("password","")),row["password_hash"]):
                return self.send(401,json.dumps({"error":"invalid credentials"}),"application/json")
            token=secrets.token_urlsafe(32); c.execute("INSERT INTO sessions(token,user_id) VALUES(?,?)",(token,row["id"])); c.commit()
            return self.send(200,json.dumps({"token":token}),"application/json")
        uid=self.token_user()
        if not uid: return self.send(401,json.dumps({"error":"authentication required"}),"application/json")
        if path=="/api/projects":
            name=str(data.get("name","")).strip()
            if not name: return self.send(400,json.dumps({"error":"name required"}),"application/json")
            cur=c.execute("INSERT INTO projects(user_id,name) VALUES(?,?)",(uid,name)); c.commit()
            return self.send(201,json.dumps({"id":cur.lastrowid,"name":name}),"application/json")
        if path=="/api/scans":
            pid=data.get("project_id")
            p=c.execute("SELECT * FROM projects WHERE id=? AND user_id=?",(pid,uid)).fetchone()
            if not p: return self.send(404,json.dumps({"error":"project not found"}),"application/json")
            cfg=data.get("config")
            if not isinstance(cfg,dict): return self.send(400,json.dumps({"error":"config object required"}),"application/json")
            tmp=ROOT/".api_scan.json"; tmp.write_text(json.dumps(cfg),encoding="utf-8")
            result=scan_file(tmp); tmp.unlink(missing_ok=True)
            c.execute("INSERT INTO scans(project_id,source,score,findings_json) VALUES(?,?,?,?)",(pid,"api",result["score"],json.dumps(result["findings"])))
            c.commit()
            return self.send(201,json.dumps(result),"application/json")
        self.send(404,json.dumps({"error":"unknown endpoint"}),"application/json")

if __name__=="__main__":
    db().close()
    print("AgentShield SaaS reference server: http://127.0.0.1:8787")
    ThreadingHTTPServer(("127.0.0.1",8787),Handler).serve_forever()
