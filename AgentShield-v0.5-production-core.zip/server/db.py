import sqlite3, threading, time, json, secrets
from pathlib import Path

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(
 id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS projects(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT NOT NULL,
 created_at REAL NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS scans(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, status TEXT NOT NULL,
 score INTEGER, findings_json TEXT NOT NULL, source TEXT NOT NULL,
 created_at REAL NOT NULL, finished_at REAL,
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS audit_log(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, project_id TEXT,
 action TEXT NOT NULL, metadata_json TEXT NOT NULL, created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS baselines(
 project_id TEXT PRIMARY KEY, scan_id TEXT NOT NULL,
 findings_hash TEXT NOT NULL, created_at REAL NOT NULL,
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);
"""

class DB:
    def __init__(self, path="agentshield.db"):
        self.path = str(path)
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        with self.lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    def close(self): self.conn.close()

    def user(self, email):
        with self.lock:
            return self.conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()

    def add_user(self, uid, email, ph):
        with self.lock:
            self.conn.execute("INSERT INTO users VALUES(?,?,?,?)",(uid,email,ph,time.time()))
            self.conn.commit()

    def project(self, pid, uid=None):
        q="SELECT * FROM projects WHERE id=?"
        args=[pid]
        if uid is not None: q += " AND user_id=?"; args.append(uid)
        with self.lock: return self.conn.execute(q,args).fetchone()

    def add_project(self,pid,uid,name):
        with self.lock:
            self.conn.execute("INSERT INTO projects VALUES(?,?,?,?)",(pid,uid,name,time.time()))
            self.conn.commit()

    def add_scan(self,sid,pid,status,source):
        with self.lock:
            self.conn.execute("INSERT INTO scans(id,project_id,status,score,findings_json,source,created_at) VALUES(?,?,?,?,?,?,?)",
                              (sid,pid,status,None,"[]",source,time.time()))
            self.conn.commit()

    def finish_scan(self,sid,score,findings):
        with self.lock:
            self.conn.execute("UPDATE scans SET status='completed',score=?,findings_json=?,finished_at=? WHERE id=?",
                              (score,json.dumps(findings,separators=(",",":")),time.time(),sid))
            self.conn.commit()

    def fail_scan(self,sid,reason):
        with self.lock:
            self.conn.execute("UPDATE scans SET status='failed',findings_json=?,finished_at=? WHERE id=?",
                              (json.dumps([{"error":reason}]),time.time(),sid))
            self.conn.commit()

    def scans(self,pid,limit=50):
        with self.lock:
            return self.conn.execute("SELECT * FROM scans WHERE project_id=? ORDER BY created_at DESC LIMIT ?",(pid,limit)).fetchall()

    def audit(self,uid,pid,action,meta):
        with self.lock:
            self.conn.execute("INSERT INTO audit_log(user_id,project_id,action,metadata_json,created_at) VALUES(?,?,?,?,?)",
                              (uid,pid,action,json.dumps(meta,separators=(",",":")),time.time()))
            self.conn.commit()

    def set_baseline(self,pid,sid,h):
        with self.lock:
            self.conn.execute("INSERT OR REPLACE INTO baselines VALUES(?,?,?,?)",(pid,sid,h,time.time()))
            self.conn.commit()

    def baseline(self,pid):
        with self.lock: return self.conn.execute("SELECT * FROM baselines WHERE project_id=?",(pid,)).fetchone()
