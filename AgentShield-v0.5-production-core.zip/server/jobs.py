import queue, threading, hashlib, json, traceback
from .db import DB

class ScanQueue:
    def __init__(self, db, scanner):
        self.db=db; self.scanner=scanner; self.q=queue.Queue(); self.stop_event=threading.Event()
        self.worker=threading.Thread(target=self._run,daemon=True,name="agentshield-scan-worker"); self.worker.start()

    def submit(self, scan_id, project_id, target):
        self.q.put((scan_id,project_id,target))

    def _run(self):
        while not self.stop_event.is_set():
            try: item=self.q.get(timeout=.2)
            except queue.Empty: continue
            sid,pid,target=item
            try:
                result=self.scanner(target)
                findings=result.get("findings",result if isinstance(result,list) else [])
                score=result.get("score",100) if isinstance(result,dict) else 100
                self.db.finish_scan(sid,score,findings)
            except Exception as e:
                self.db.fail_scan(sid, type(e).__name__)
            finally: self.q.task_done()

    def shutdown(self):
        self.stop_event.set(); self.worker.join(timeout=2)
