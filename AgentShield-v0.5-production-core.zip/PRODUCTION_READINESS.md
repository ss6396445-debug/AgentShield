# AgentShield v0.5 Production Core

## Added
- SQLite persistence layer with foreign-key tenant isolation.
- Background scan queue abstraction.
- Audit log and scan baseline storage.
- Deterministic reviewer gates for finding schema and secret disclosure.
- Baseline/diff helpers.
- Docker deployment reference and Compose.
- Migration SQL.
- QA tests for persistence, isolation, review gates, and diff behavior.

## Still required for public production
- PostgreSQL + migrations in managed infrastructure.
- Redis/queue or managed job system for horizontal workers.
- GitHub App with OAuth/PKCE and verified webhook signatures.
- Stripe billing + signed webhook processing.
- KMS/secret manager, TLS termination, WAF/rate limits.
- Email verification/password reset.
- Object storage for artifacts with encryption and retention controls.
- Centralized metrics/logging/tracing and alerting.
- Independent penetration test and legal/privacy review.
- Real customer pilot before broad launch.

This release does not claim those external services or human reviews have been completed.
