PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(
 id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS projects(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT NOT NULL,
 created_at REAL NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS scans(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL, status TEXT NOT NULL,
 score INTEGER, findings_json TEXT NOT NULL, source TEXT NOT NULL,
 created_at REAL NOT NULL, finished_at REAL,
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS audit_log(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, project_id TEXT,
 action TEXT NOT NULL, metadata_json TEXT NOT NULL, created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS baselines(
 project_id TEXT PRIMARY KEY, scan_id TEXT NOT NULL,
 findings_hash TEXT NOT NULL, created_at REAL NOT NULL,
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);
